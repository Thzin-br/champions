<?php
$host = "mysql2.serv00.com";
$user = "m1607_champions";
$password = "Anonymous100!!";
$database = "m1607_champions";

// Conexão com o banco de dados
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>