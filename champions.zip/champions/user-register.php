<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário - Sistema de Chaveamento</title>
    <link rel="stylesheet" href="styles.css">
    <!-- Importação de Font Awesome para ícones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="login-wrapper user-register">
        <form action="create.php" method="POST" class="login-form" id="user-register-form" aria-labelledby="register-title">
            <h2 id="register-title">Cadastro de Usuário</h2>
            
            <!-- Mensagem de Erro -->
            <div class="error-message" id="user-register-error-message" role="alert" aria-live="assertive"></div>

            <!-- Campo de Nome -->
            <div class="input-group">
                <label for="register-name">Nome</label>
                <input type="text" id="register-username" name="name" placeholder="Digite seu Nome" required aria-required="true">
                <small class="input-error" id="register-name-error"></small>
            </div>

            <!-- Campo de E-mail -->
            <div class="input-group">
                <label for="register-username">E-mail</label>
                <input type="text" id="register-username" name="username" placeholder="Digite seu e-mail" required aria-required="true">
                <small class="input-error" id="register-username-error"></small>
            </div>

            <!-- Campo de Senha -->
            <div class="input-group">
                <label for="register-password">Senha</label>
                <div class="password-wrapper">
                    <input type="password" id="register-password" name="password" placeholder="Digite sua senha" required aria-required="true">
                    <button type="button" id="register-toggle-password" aria-label="Mostrar senha">
                        <i class="fa fa-eye" id="register-eye-icon"></i>
                    </button>
                </div>
                <small class="input-error" id="register-password-error"></small>
            </div>

            <!-- Campo de Confirmação de Senha -->
            <div class="input-group">
                <label for="register-confirm-password">Confirmar Senha</label>
                <div class="password-wrapper">
                    <input type="password" id="register-confirm-password" name="confirm-password" placeholder="Confirme sua senha" required aria-required="true">
                    <button type="button" id="register-toggle-confirm-password" aria-label="Mostrar senha">
                        <i class="fa fa-eye" id="register-confirm-eye-icon"></i>
                    </button>
                </div>
                <small class="input-error" id="register-confirm-password-error"></small>
            </div>

            <!-- Medidor de Força da Senha -->
            <div class="input-group">
                <label for="password-strength">Força da Senha</label>
                <div id="password-strength" class="password-strength">
                    <div class="strength-bar"></div>
                    <span class="strength-text">Fraca</span>
                </div>
            </div>

            <!-- Botões de Submissão e Navegação -->
            <div class="button-group">
                <button style="background-color: red;" type="submit" class="btn-login">Cadastrar</button>
            </div>

            <!-- Links de Ação -->
            <div class="action-links">
                <a style="color: red;" href="index.php" id="register-login-link" class="register-user">
                    <i style="color: red;" class="fa fa-sign-in-alt"></i> Já tem uma conta? Faça Login
                </a>
            </div>
        </form>
    </div>

    <script src="user-register.js"></script>
</body>
</html>
