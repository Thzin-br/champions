<?php
session_start();

// Verifique se o usuário está logado
if (!isset($_SESSION['email'])) {
    header('Location: ../index.php'); // Redirecione para a página de login
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script defer src="script.js"></script>
    <title>Criar Torneio - Street Fighter Championship</title>
</head>
<body>
    <header class="navbar navbar-expand-lg navbar-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand mx-auto" href="#">
                <i class="fas fa-fist-raised text-danger"></i> Street Fighter Championship
            </a>
        </div>
    </header>
    <main class="container mt-5">
        <section class="card shadow-lg p-4 mb-5 mx-auto" style="max-width: 600px;">
            <h2 class="card-title text-center mb-4">Criar Novo Torneio</h2>
            <form id="create-tournament-form">
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome do Torneio:</label>
                    <input type="text" id="nome" name="nome" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="data" class="form-label">Data do Torneio:</label>
                    <input type="date" id="data" name="data" class="form-control" required>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Criar Torneio</button>
                </div>
            </form>
        </section>
    </main>
    <footer class="text-center p-3 mt-5">
        <p>Street Fighter Championship &copy; 2024</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
