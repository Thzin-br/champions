<?php
include 'db_connect.php';
  
if (isset($_GET['ID'])) {
  $id = $_GET['ID'];
  $sql = "DELETE FROM usuario WHERE ID =$id";
  
  if ($conn->query($sql) === TRUE) {
    header("Location: admin.php");
  }else{
    echo "Erro:" . $sql . "<br>" . $conn->error;
   }
}
?>