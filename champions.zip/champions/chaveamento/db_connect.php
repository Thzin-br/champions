
<?php
$servername = "mysql2.serv00.com";
$username = "m1607_champions"; // Substitua pelo usuário correto do banco
$password = "Anonymous100!!"; // Substitua pela senha correta do banco
$dbname = "m1607_champions";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>
