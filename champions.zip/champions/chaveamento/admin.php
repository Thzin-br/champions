<?php
session_start();
include 'db_connect.php';

// Verifique se o usuário está logado
if (!isset($_SESSION['email'])) {
    header('Location: ../index.php'); // Redirecione para a página de login
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script defer src="script.js"></script>
    <title>Administração - Street Fighter Championship</title>
</head>
<body>
    <header class="navbar navbar-expand-lg navbar-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="fas fa-tools text-warning"></i> Painel Administrativo
            </a>
            <a href="./index.php" id="home-btn" class="btn btn-outline-light ms-auto">Início</a>
        </div>
    </header>
    <main class="container mt-5">
        <section class="card shadow-lg p-4">
            <h2 class="card-title text-center mb-4">Gerenciar Usuários</h2>
            <table class="table table-hover table-dark table-striped">
                <thead class="table-danger">
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Senha</th>
                        <th>Nível</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="tournament-list">
                    <?php
                     $sql = "SELECT * FROM usuario";
                     $result = $conn->query($sql);
  
                     if ($result->num_rows > 0) {
                       while ($row = $result->fetch_assoc()) {
                         echo "
                         <tr>
                           <td>{$row['NOME']}</td>
                           <td>{$row['EMAIL']}</td>
                           <td>{$row['SENHA']}</td>
                           <td>{$row['NIVEL_ACESSO']}</td>
                           <td>
                               <a href='edit.php?ID={$row['ID']}'>Editar</a>
                               <a href='delete.php?ID={$row['ID']}'>Excluir</a>
                         </tr>";
                        }
                      }else{
                        echo "<tr><td colspan='5'>Nenhum usuário encontrado.</td></tr>";
                      }
                      ?>
                </tbody>
            </table>
        </section>
    </main>
    <footer class="text-center p-3 mt-5">
        <p>Administração Street Fighter Championship &copy; 2024</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
