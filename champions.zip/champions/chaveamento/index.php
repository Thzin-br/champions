<?php
session_start();

// Verifique se o usuário está logado
if (!isset($_SESSION['email'])) {
    header('Location: ../index.php'); // Redirecione para a página de login
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script defer src="script.js"></script>
    <title>Street Fighter Championship - Página Inicial</title>
</head>
<body>
    <header class="navbar navbar-expand-lg navbar-dark p-3">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <a class="navbar-brand" href="#">
                <i class="fas fa-fist-raised text-danger"></i> Street Fighter Championship
            </a>
            <nav class="d-flex">
                <a href="profile.php" id="profile-btn" class="btn btn-outline-light me-2">Perfil</a>
                <a href="logout.html" id="logoff-btn" class="btn btn-outline-light">Logout</a>
            </nav>
        </div>
    </header>
    <main class="container mt-5">
        <section class="card shadow-lg p-4 mb-5">
            <h2 class="card-title text-center mb-4">Torneios Ativos</h2>
            <div id="bracket-container" class="my-3">
                <!-- Brackets dos torneios ativos serão carregados dinamicamente aqui -->
            </div>
        </section>
        <!---<section class="card shadow-lg p-4">
            <h2 class="card-title text-center mb-4">Próximos Torneios</h2>
            <div id="upcoming-tournaments" class="my-3">
                <!-- Próximos torneios serão carregados dinamicamente aqui -->
            </div>
        </section>
    </main>
    <footer class="text-center p-3 mt-5">
        <p>Street Fighter Championship &copy; 2024</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
