<?php
session_start();
include_once('./db_connect.php');

// Verifique se o usuário está logado
if (!isset($_SESSION['email'])) {
    header('Location: ../index.php'); // Redirecione para a página de login
    exit;
}
  
$email = $_SESSION['email'];
  
$sql = "SELECT * FROM usuario WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s",$email);
$stmt->execute();
$result = $stmt->get_result();
  
if ($result->num_rows > 0) {
  $user_data = $result->fetch_assoc();
} else {
  echo "Usuário não encontrado!";
  exit();
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script defer src="script.js"></script>
    <title>Perfil - Street Fighter Championship</title>
</head>
<body>
    <header class="navbar navbar-expand-lg navbar-dark p-3">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <a class="navbar-brand" href="#">
                <i class="fas fa-user-circle text-warning"></i> Perfil do Usuário
            </a>
            <nav class="d-flex">
                <a href="index.php" id="home-btn" class="btn btn-outline-light me-2">Início</a>
                <a href="sair.php" id="logoff-btn" class="btn btn-outline-light">Logout</a>
            </nav>
        </div>
    </header>
    <main class="container mt-5">
        <section class="card shadow-lg p-4 mb-5">
            <h2 class="card-title">Informações do Perfil</h2>
            <p style="color: white;"><?php echo htmlspecialchars($user_data['NOME']);?></p>
            <p style="color: white;"><?php echo htmlspecialchars($user_data['EMAIL']);?></p>
            <p style="color: white;"><?php echo htmlspecialchars($user_data['NIVEL_ACESSO']);?></p>
            <!--<h2 class="card-title mt-4">Torneios Participados</h2>-->
            <!--<div id="tournaments-list" class="mt-3">-->
                <!-- Torneios participados serão carregados dinamicamente -->
            <!--</div>-->
        </section>
    </main>
    <footer class="text-center p-3 mt-5">
        <p>Street Fighter Championship &copy; 2024</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
