<?php
include 'db_connect.php';
  
if (isset($_GET['ID'])) {
  $id = $_GET['ID'];
  $sql = "SELECT * FROM usuario WHERE ID=$id";
  $result = $conn->query($sql);
  $user = $result->fetch_assoc();
}
  
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nome = $_POST['NOME'];
  $senha = $_POST['SENHA'];
  $email = $_POST['EMAIL'];
  $nivel = $_POST['NIVEL_ACESSO'];
  
  $sql = "UPDATE usuario SET NOME='$nome',SENHA='$senha',EMAIL='$email',NIVEL_ACESSO='$nivel' WHERE ID=$id";
  
  if ($conn->query($sql) === TRUE) {
    header("Location: admin.php");
   }else{
     echo "Erro:" . $sql . "<br>" . $conn->error;
   }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Editar Usuário</title>
</head>
<body>
  <form action=""method="POST">
    <input type="text" name="NOME" value="<?=$user['NOME'] ?>" required>
    <input type="text" name="SENHA" value="<?=$user['SENHA'] ?>" required>
    <input type="text" name="EMAIL" value="<?=$user['EMAIL'] ?>" required>
    <input type="text" name="NIVEL_ACESSO" value="<?=$user['NIVEL_ACESSO'] ?>" required>
    <button type="submit">Atualizar</button>
  </form>
</body>
</html>