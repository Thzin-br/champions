<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['name'];
    $senha = $_POST['password'];
    $email = $_POST['username'];
    $nivel_acesso = 'Player';

    $stmt = $conn->prepare("INSERT INTO usuario (NOME, SENHA, EMAIL, NIVEL_ACESSO) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nome, $senha, $email, $nivel_acesso);

    if ($stmt->execute() === TRUE) {
        header("Location: index.php");
        exit;
    } else {
        echo "Erro: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>