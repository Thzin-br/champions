// Seleção de Elementos
const userPasswordInput = document.getElementById('user-password');
const userTogglePasswordBtn = document.getElementById('user-toggle-password');
const userEyeIcon = document.getElementById('user-eye-icon');

// Função para Alternar Visibilidade da Senha
function toggleUserPasswordVisibility() {
    const type = userPasswordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    userPasswordInput.setAttribute('type', type);

    // Alternar ícone
    if (type === 'password') {
        userEyeIcon.classList.remove('fa-eye-slash');
        userEyeIcon.classList.add('fa-eye');
        userTogglePasswordBtn.setAttribute('aria-label', 'Mostrar senha');
    } else {
        userEyeIcon.classList.remove('fa-eye');
        userEyeIcon.classList.add('fa-eye-slash');
        userTogglePasswordBtn.setAttribute('aria-label', 'Ocultar senha');
    }
}

// Evento para Alternar Visibilidade da Senha
userTogglePasswordBtn.addEventListener('click', toggleUserPasswordVisibility);