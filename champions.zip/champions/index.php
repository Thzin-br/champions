<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login de Usuário - Sistema de Chaveamento</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="login-wrapper user-login">
        <form action="testelogin.php" method="POST" class="login-form" id="user-login-form" aria-labelledby="login-title">
            <h2 id="login-title">Login de Usuário</h2>
            
            <!-- Mensagem de Erro -->
            <div class="error-message" id="user-error-message" role="alert" aria-live="assertive">
                <?php
                session_start();
                if (isset($_SESSION['error'])) {
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                }
                ?>
            </div>

            <!-- Campo de E-mail -->
            <div class="input-group">
                <label for="user-username">E-mail</label>
                <input type="text" id="user-username" name="username" placeholder="Digite seu e-mail" required aria-required="true">
                <small class="input-error" id="user-username-error"></small>
            </div>

            <!-- Campo de Senha -->
            <div class="input-group">
                <label for="user-password">Senha</label>
                <div class="password-wrapper">
                    <input type="password" id="user-password" name="password" placeholder="Digite sua senha" required aria-required="true">
                    <button type="button" id="user-toggle-password" aria-label="Mostrar senha">
                        <i class="fa fa-eye" id="user-eye-icon"></i>
                    </button>
                </div>
                <small class="input-error" id="user-password-error"></small>
            </div>

            <!-- Botões de Submissão e Navegação -->
            <div class="button-group">
                <button style="background-color: red;" type="submit" name="submit" class="btn-login">Entrar</button>
            </div>

            <!-- Links de Ação -->
            <div class="action-links">
                <a style="color: red" href="user-register.php" id="user-register-link" class="register-user">
                    <i style="color: red;" class="fa fa-user-plus"></i> Não tem uma conta? Cadastre-se
                </a>
            </div>
        </form>
    </div>

    <script src="user-login.js"></script>
</body>
</html>
