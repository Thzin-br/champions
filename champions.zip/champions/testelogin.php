<?php
session_start();
include_once('./config.php'); // Inclua a conexão com o banco de dados

if(isset($_POST['submit']) && !empty($_POST['username']) && !empty($_POST['password'])) {
    $email = $_POST['username'];
    $password = $_POST['password'];

    // Prepare a consulta
    $stmt = $conn->prepare("SELECT * FROM usuario WHERE EMAIL = ?");
    if ($stmt === false) {
        die("Erro na preparação da consulta: " . $conn->error);
    }
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows < 1) {
        $_SESSION['error'] = 'Usuário ou senha incorretos.';
        header('Location: index.php');
        exit;
    } else {
        $user = $result->fetch_assoc();
        // Verifique a senha aqui com password_verify se estiver usando hash
        if($password === $user['SENHA']) { // Trocar para password_verify após hash
            $_SESSION['email'] = $email;
            // Redirecionamento baseado no nível de acesso
            if($user['NIVEL_ACESSO'] === 'PLAYER') {
                header('Location: ./chaveamento/index.php');
            } else if($user['NIVEL_ACESSO'] === 'ADM') {
                header('Location: ./chaveamento/admin.php');
            } else {
                header('Location: index.php');
            }
            exit;
        } else {
            $_SESSION['error'] = 'Usuário ou senha incorretos.';
            header('Location: index.php');
            exit;
        }
    }
} else {
    header('Location: index.php');
    exit;
}
?>