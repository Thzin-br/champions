// Seleção de Elementos
const userRegisterForm = document.getElementById('user-register-form');
const registerPasswordInput = document.getElementById('register-password');
const registerConfirmPasswordInput = document.getElementById('register-confirm-password');
const registerTogglePasswordBtn = document.getElementById('register-toggle-password');
const registerEyeIcon = document.getElementById('register-eye-icon');
const registerToggleConfirmPasswordBtn = document.getElementById('register-toggle-confirm-password');
const registerConfirmEyeIcon = document.getElementById('register-confirm-eye-icon');
const registerPasswordError = document.getElementById('register-password-error');
const registerConfirmPasswordError = document.getElementById('register-confirm-password-error');
const passwordStrengthIndicator = document.getElementById('password-strength');
const navigateLoginBtn = document.getElementById('navigate-login-btn');

// Função para Verificar a Força da Senha
function isPasswordStrong(password) {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /[0-9]/.test(password);
    const hasSymbols = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    return password.length >= minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSymbols;
}

// Função para Atualizar o Medidor de Força da Senha
function updatePasswordStrength(password) {
    let strength = 0;

    if (password.length >= 8) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength += 1;

    if (strength <= 2) {
        passwordStrengthIndicator.className = 'password-strength weak';
        passwordStrengthIndicator.querySelector('.strength-text').textContent = 'Fraca';
    } else if (strength === 3) {
        passwordStrengthIndicator.className = 'password-strength medium';
        passwordStrengthIndicator.querySelector('.strength-text').textContent = 'Média';
    } else if (strength === 4) {
        passwordStrengthIndicator.className = 'password-strength strong';
        passwordStrengthIndicator.querySelector('.strength-text').textContent = 'Forte';
    } else if (strength >= 5) {
        passwordStrengthIndicator.className = 'password-strength very-strong';
        passwordStrengthIndicator.querySelector('.strength-text').textContent = 'Muito Forte';
    }
}

// Função para Validar Formulário
function validateRegisterForm() {
    let valid = true;

    // Reset de mensagens de erro
    registerPasswordError.style.display = 'none';
    registerConfirmPasswordError.style.display = 'none';

    // Validação da Senha
    if (registerPasswordInput.value.trim() === '') {
        registerPasswordError.textContent = 'Senha é obrigatória.';
        registerPasswordError.style.display = 'block';
        valid = false;
    } else if (!isPasswordStrong(registerPasswordInput.value.trim())) {
        registerPasswordError.textContent = 'A senha é muito fraca.';
        registerPasswordError.style.display = 'block';
        valid = false;
    }

    // Validação da Confirmação de Senha
    if (registerConfirmPasswordInput.value.trim() === '') {
        registerConfirmPasswordError.textContent = 'Confirme sua senha.';
        registerConfirmPasswordError.style.display = 'block';
        valid = false;
    } else if (registerPasswordInput.value.trim() !== registerConfirmPasswordInput.value.trim()) {
        registerConfirmPasswordError.textContent = 'As senhas não correspondem.';
        registerConfirmPasswordError.style.display = 'block';
        valid = false;
    }

    return valid;
}

// Função para Alternar Visibilidade da Senha
function toggleRegisterPasswordVisibility() {
    const type = registerPasswordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    registerPasswordInput.setAttribute('type', type);

    // Alternar ícone
    if (type === 'password') {
        registerEyeIcon.classList.remove('fa-eye-slash');
        registerEyeIcon.classList.add('fa-eye');
        registerTogglePasswordBtn.setAttribute('aria-label', 'Mostrar senha');
    } else {
        registerEyeIcon.classList.remove('fa-eye');
        registerEyeIcon.classList.add('fa-eye-slash');
        registerTogglePasswordBtn.setAttribute('aria-label', 'Ocultar senha');
    }
}

function toggleRegisterConfirmPasswordVisibility() {
    const type = registerConfirmPasswordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    registerConfirmPasswordInput.setAttribute('type', type);

    // Alternar ícone
    if (type === 'password') {
        registerConfirmEyeIcon.classList.remove('fa-eye-slash');
        registerConfirmEyeIcon.classList.add('fa-eye');
        registerToggleConfirmPasswordBtn.setAttribute('aria-label', 'Mostrar senha');
    } else {
        registerConfirmEyeIcon.classList.remove('fa-eye');
        registerConfirmEyeIcon.classList.add('fa-eye-slash');
        registerToggleConfirmPasswordBtn.setAttribute('aria-label', 'Ocultar senha');
    }
}

// Evento para Alternar Visibilidade da Senha
registerTogglePasswordBtn.addEventListener('click', toggleRegisterPasswordVisibility);
registerToggleConfirmPasswordBtn.addEventListener('click', toggleRegisterConfirmPasswordVisibility);

// Evento para Atualizar Medidor de Força da Senha
registerPasswordInput.addEventListener('input', function() {
    const password = registerPasswordInput.value.trim();
    updatePasswordStrength(password);
});